package com.app.dto;

public class FormIdDto {

	private int userid;

	public FormIdDto(int userid) {
		this.userid = userid;
	}

	public FormIdDto() {
	}

	public int getUserid() {
		return userid;
	}

	public void setUserid(int userid) {
		this.userid = userid;
	}
	
	
	
	
	
	
	
}
