package com.app.pojos;

public enum Catagory 
{

	FORESTPARK , RIVERPARK;
	
}
