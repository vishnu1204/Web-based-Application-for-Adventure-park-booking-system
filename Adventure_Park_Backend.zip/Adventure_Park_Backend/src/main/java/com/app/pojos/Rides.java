package com.app.pojos;


import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.EnumType;
import javax.persistence.Enumerated;

import javax.persistence.Table;

@Entity
@Table(name = "Rides")
public class Rides extends BaseEntity  {
	@Column
	private String name;
	@Column(length = 20)
	@Enumerated(EnumType.STRING)
	private Catagory catagory;
	@Column(name = "Price")
	private double price;
	@Column
	private String info;

	
	public Rides() {

	}

	public Catagory getCatagory() {
		return catagory;
	}

	public void setCatagory(Catagory catagory) {
		this.catagory = catagory;
	}

	public double getPrice() {
		return price;
	}

	public void setPrice(double price) {
		this.price = price;
	}

	public String getName() {
		return name;
	}

	public void setName(String name) {
		this.name = name;
	}

	public String getInfo() {
		return info;
	}

	public void setInfo(String info) {
		this.info = info;
	}


	
	
	
	

}
